成品包说明

来源任务：job_56db2587-ba85-499a-b4cd-5756148d6f90
商品数量：3
待补价：1
跳过：0

1. 本包可直接上传到商家后台的「成品包导入」。
2. 缺 price 的商品会被跳过，请先填 price-sheet.csv 的 fillPriceHere 列。
3. desc_en 与 sell_points 是内容侧产出，需商家后台开启跨境字段写入才会落库。
4. publish 为 false 时商品以下架态导入，需人工确认后再发布。